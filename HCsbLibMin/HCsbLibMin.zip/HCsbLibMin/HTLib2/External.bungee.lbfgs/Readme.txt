http://bungee-view.googlecode.com/svn-history/r120/trunk/lbfgs/edu/cmu/cs/bungee/lbfgs/
http://bungee-view.googlecode.com/svn-history/r120/trunk/lbfgs/edu/cmu/cs/bungee/lbfgs/LBFGS.java
http://bungee-view.googlecode.com/svn-history/r120/trunk/lbfgs/edu/cmu/cs/bungee/lbfgs/Mcsrch.java
