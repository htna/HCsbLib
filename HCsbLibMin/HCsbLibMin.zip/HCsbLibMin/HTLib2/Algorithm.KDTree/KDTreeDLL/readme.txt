﻿This file is referenced from:
- http://www.cs.wlu.edu/~levy/software/kd/
- http://www.cs.wlu.edu/~levy/software/kd/KDTreeDLL.zip
