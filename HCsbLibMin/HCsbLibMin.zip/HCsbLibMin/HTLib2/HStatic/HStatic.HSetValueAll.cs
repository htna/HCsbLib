﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HTLib2
{
    public static partial class HStatic
    {
        //public static T[] HSetValueAll<T>(this IList<T> arr, T val)
        //{
        //    T[] narr = new T[arr.Count];
        //    for(int i=0; i<narr.Length; i++)
        //        narr[i] = val;
        //    return narr;
        //}
        //public static T[,] HSetValueAll<T>(this T[,] arr, T val)
        //{
        //    T[,] narr = new T[arr.GetLength(0), arr.GetLength(1)];
        //    for(int c=0; c<narr.GetLength(0); c++)
        //        for(int r=0; r<narr.GetLength(1); r++)
        //            narr[c, r] = val;
        //    return narr;
        //}
    }
}
