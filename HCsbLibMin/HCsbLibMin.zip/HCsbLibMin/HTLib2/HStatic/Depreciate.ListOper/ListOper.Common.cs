using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace HTLib2
{
    public static partial class ListOpers
	{
        //public static List<int> IndexCommon<T>(this IList<T> list1, IList<T> list2)
        //{
        //    List<int> idxcommon = new List<int>();
        //    for(int idx1=0; idx1<list1.Count; idx1++)
        //    {
        //        int idx2 = list2.IndexOf(list1[idx1]);
        //        if(idx2 == -1)
        //            continue;
        //        idxcommon.Add(idx1);
        //    }
        //    return idxcommon;
        //}
    }
}
