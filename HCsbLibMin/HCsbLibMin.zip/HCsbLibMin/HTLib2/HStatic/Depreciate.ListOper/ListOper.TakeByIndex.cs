using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace HTLib2
{
    public static partial class ListOpers
	{
        //public static T[] SelectByIndex<T>(this T[] list, IList<int> idx) { return SelectByIndex(new List<T>(list), idx).ToArray(); }
        //public static List<T> SelectByIndex<T>(this IList<T> list, IList<int> idx) { return SelectByIndex(new List<T>(list), idx); }
        //public static List<T> SelectByIndex<T>(this List<T> list, IList<int> idx)
        //{
        //    List<T> select = new List<T>(idx.Count);
        //    for(int i=0; i<idx.Count; i++)
        //        select.Add(list[idx[i]]);
        //    return select;
        //}
    }
}
