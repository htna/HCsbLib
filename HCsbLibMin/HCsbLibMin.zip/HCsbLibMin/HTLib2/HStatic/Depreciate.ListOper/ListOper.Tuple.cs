using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace HTLib2
{
    public static partial class ListOpers
	{
        //public static T1[] ListItem1<T1,T2>         (this IList<Tuple<T1,T2>>          list) { T1[] items = new T1[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item1; return items; }
        //public static T2[] ListItem2<T1,T2>         (this IList<Tuple<T1,T2>>          list) { T2[] items = new T2[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item2; return items; }

        //public static T1[] ListItem1<T1, T2, T3>    (this IList<Tuple<T1, T2, T3>>     list) { T1[] items = new T1[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item1; return items; }
        //public static T2[] ListItem2<T1, T2, T3>    (this IList<Tuple<T1, T2, T3>>     list) { T2[] items = new T2[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item2; return items; }
        //public static T3[] ListItem3<T1, T2, T3>    (this IList<Tuple<T1, T2, T3>>     list) { T3[] items = new T3[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item3; return items; }

        //public static T1[] ListItem1<T1, T2, T3, T4>(this IList<Tuple<T1, T2, T3, T4>> list) { T1[] items = new T1[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item1; return items; }
        //public static T2[] ListItem2<T1, T2, T3, T4>(this IList<Tuple<T1, T2, T3, T4>> list) { T2[] items = new T2[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item2; return items; }
        //public static T3[] ListItem3<T1, T2, T3, T4>(this IList<Tuple<T1, T2, T3, T4>> list) { T3[] items = new T3[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item3; return items; }
        //public static T4[] ListItem4<T1, T2, T3, T4>(this IList<Tuple<T1, T2, T3, T4>> list) { T4[] items = new T4[list.Count]; for(int i=0; i<list.Count; i++) items[i]=list[i].Item4; return items; }
    }
}
