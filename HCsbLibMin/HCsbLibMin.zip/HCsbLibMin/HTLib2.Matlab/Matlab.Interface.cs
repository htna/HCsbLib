using System;
using System.Collections.Generic;
using System.Text;

namespace HTLib2
{
    using Mutex = System.Threading.Mutex;
    using AbandonedMutexException = System.Threading.AbandonedMutexException;
    public partial class Matlab
    {
    }
}
